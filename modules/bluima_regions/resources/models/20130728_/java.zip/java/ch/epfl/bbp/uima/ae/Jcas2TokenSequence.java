package ch.epfl.bbp.uima.ae;

import static com.google.common.collect.Lists.newArrayList;
import static org.uimafit.util.CasUtil.indexCovering;
import static org.uimafit.util.JCasUtil.getType;
import static org.uimafit.util.JCasUtil.select;
import static org.uimafit.util.JCasUtil.selectCovered;

import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.uima.cas.text.AnnotationFS;
import org.apache.uima.jcas.JCas;

import cc.mallet.pipe.Pipe;
import cc.mallet.types.Instance;
import cc.mallet.types.TokenSequence;
import ch.epfl.bbp.uima.types.BrainRegion;
import ch.epfl.bbp.uima.types.BrainRegionDictTerm;
import de.julielab.jules.types.Sentence;
import de.julielab.jules.types.Token;

/**
 * Creates a {@link cc.mallet.types.TokenSequence} from a {@link JCas}, reusing
 * the UIMA {@link Sentence} and {@link Token}. Sets the (true) label based on
 * the presence of a {@link BrainRegion} covering the {@link Token}.
 * 
 * @author renaud.richardet@epfl.ch
 */
public class Jcas2TokenSequence extends Pipe {
    private static final long serialVersionUID = 1L;

    public static final String PROPERTY_POS = "u_POS_";
    public static final String PROPERTY_VERB_LEMMA = "u_V_LEM_";

    public static final String TARGET_I = "I";
    public static final String TARGET_O = "O";

    /**
     * IN: one {@link JCas} <br/>
     * data : 1 {@link JCas}<br>
     * targ : none<br>
     * name : pmId<br>
     * srce : {@link JCas}<br>
     * <br>
     * OUT: {@link Instance}s, each corresponding to a {@link Sentence}<br/>
     * data : a {@link TokenSequence}, one {@link cc.mallet.types.Token} per
     * UIMA {@link Token}<br>
     * targ : labels for training (if any), based on covering UIMA
     * {@link BrainRegion} annotations<br>
     * name : pmId<br>
     * srce : {@link Sentence}<br>
     * <br>
     * Note: this {@link Pipe} creates more {@link Instance} than it gets (one
     * output {@link Instance} per input {@link Sentence}).
     */
    @Override
    public Iterator<Instance> newIteratorFrom(Iterator<Instance> source) {
        List<Instance> output = new LinkedList<Instance>();

        while (source.hasNext()) {
            Instance carrier = (Instance) source.next();
            JCas jCas = (JCas) carrier.getData();
            int pmId = (Integer) carrier.getName();

            // gold labels from training corpus
            // key: each token; value: a list of BR covering that token
            final Map<AnnotationFS, Collection<AnnotationFS>> coveringBrainRegions = indexCovering(
                    jCas.getCas(), //
                    getType(jCas, Token.class),
                    getType(jCas, BrainRegionDictTerm.class));

            int i = 0;
            for (Sentence s : select(jCas, Sentence.class)) {

                List<cc.mallet.types.Token> data = newArrayList();
                TokenSequence target = new TokenSequence();

                for (Token t : selectCovered(Token.class, s)) {

                    cc.mallet.types.Token malletToken = new cc.mallet.types.Token(
                            t.getCoveredText());
                    data.add(malletToken);

                    // POS, LEMMA
                    malletToken.setFeatureValue(PROPERTY_POS + t.getPos(), 1.0);
//                    if (t.getPos() != null && t.getPos().startsWith("V")) {
//                        malletToken.setFeatureValue(
//                                PROPERTY_VERB_LEMMA + t.getLemmaStr(), 1.0);
//                    }

                    // TARGET annots for brain regions
                    if (coveringBrainRegions.containsKey(t)) {
                        target.add(TARGET_I);
                    } else {
                        target.add(TARGET_O);
                    }
                }

                output.add(new Instance(new TokenSequence(data), target, pmId
                        + "__" + i, null));
                i++;
            }
        }
        return output.iterator();
    }
}
