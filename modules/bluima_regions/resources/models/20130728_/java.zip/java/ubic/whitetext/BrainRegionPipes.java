package ubic.whitetext;

import static ch.epfl.bbp.uima.BrainRegionsHelper.LEXICON_HOME;
import static com.google.common.collect.Lists.newArrayList;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.regex.Pattern;

import cc.mallet.pipe.Pipe;
import cc.mallet.pipe.Target2LabelSequence;
import cc.mallet.pipe.TokenSequence2FeatureVectorSequence;
import cc.mallet.pipe.tsf.LexiconMembership;
import cc.mallet.pipe.tsf.RegexMatches;
import cc.mallet.pipe.tsf.TokenText;
import cc.mallet.pipe.tsf.TrieLexiconMembership;
import cc.mallet.share.upenn.ner.FeatureWindow;
import cc.mallet.share.upenn.ner.LengthBins;
import cc.mallet.share.upenn.ner.LongRegexMatches;
import ch.epfl.bbp.uima.ae.Jcas2TokenSequence;

/**
 * Mallet {@link Pipe}s for feature extraction.
 * 
 * @author Leon French
 * @author renaud.richardet@epfl.ch
 */
public class BrainRegionPipes {

    final private static int window = 3;

    public static List<Pipe> getPipes() throws Exception {

        List<Pipe> pipes = newArrayList();

        pipes.add(new Jcas2TokenSequence());
        pipes.add(new Target2LabelSequence());

        pipes.add(new RegexMatches("dummyPipe", Pattern.compile(".*")));

        // more piiiiipes
        addAllGoodPipes(pipes);

        pipes.add(new FeatureWindow(window, window));
        // for debugging pipes.add(new PrintInputAndTarget());
        pipes.add(new TokenSequence2FeatureVectorSequence());
        return pipes;
    }

    private static final boolean ignoreCase = true;

    public static void addAllGoodPipes(List<Pipe> pipes) throws Exception {

        List<String> usedPipeNames = new LinkedList<String>();
        addAreaRegexPipes(usedPipeNames, pipes);
        addSubstringRegexPipes(usedPipeNames, pipes);
        addSpineRegexPipes(usedPipeNames, pipes);

        addSmallLexicons(usedPipeNames, pipes, ignoreCase);
        // addAbbreviationLexiconPipes(usedPipeNames, pipes);
        addAreaLexicons(usedPipeNames, pipes, ignoreCase);

        addLengthPipes(usedPipeNames, pipes);
        addHandMadeRegexPipes(usedPipeNames, pipes);
        addMalletNEPipes(usedPipeNames, pipes);
    }

    private static void addAbbreviationLexiconPipes(List<String> usedPipeNames,
            List<Pipe> pipes) throws IOException {

        usedPipeNames.add("AbbrevLex");
        File ratMouse = new File(LEXICON_HOME + "NN2007RatMouseAbbrev.txt");
        File human = new File(LEXICON_HOME + "NN2002HumanAbbrev.txt");
        boolean ignoreCase = true;
        // should be one word only but may not..
        pipes.add(new TrieLexiconMembership("NNHuAbbrev", human, ignoreCase));
        pipes.add(new TrieLexiconMembership("NNRatMouseAbbrev", ratMouse,
                ignoreCase));

        addPrefixPipes(pipes, ratMouse, "NNHuAbbrevPrefix");
        addPrefixPipes(pipes, human, "NNRatMouseAbbrevPrefix");
    }

    public static void addPrefixPipes(List<Pipe> pipes, File file, String name)
            throws IOException {
        BufferedReader f = new BufferedReader(new FileReader(file));
        String line;
        while ((line = f.readLine()) != null) {
            line = line.trim();
            pipes.add(new RegexMatches(name, Pattern.compile("(" + line
                    + ".{1,3})", Pattern.CASE_INSENSITIVE)));
        }
        f.close();
    }

    public static void addTextPipe(List<String> usedPipeNames, List<Pipe> pipes)
            throws Exception {
        usedPipeNames.add("Text");
        pipes.add(new TokenText("text="));
    }

    public static void addAreaRegexPipes(List<String> usedPipeNames,
            List<Pipe> pipes) {
        usedPipeNames.add("Area regexes");

        // spaces were removed from regex to match the LongRegexMatches
        // behaviour
        // test with http://www.fileformat.info/tool/regex.htm
        pipes.add(new LongRegexMatches("Brodmann", Pattern
                .compile("areas? \\d+((, ?\\d)*,? (or|and) \\d+)?"), 2, 9));

        // a looser version that allows just letters
        // areas? (\p{Upper}|\d)+((, ?(\p{Upper}|\d))*,? (or|and)
        // (\p{Upper}|\d)+)?
        pipes.add(new LongRegexMatches(
                "Areas",
                Pattern.compile("areas? (\\p{Upper}|\\d)+((, ?(\\p{Upper}|\\d))*,? (or|and) (\\p{Upper}|\\d)+)?"),
                2, 9));

    }

    public static void addSubstringRegexPipes(List<String> usedPipeNames,
            List<Pipe> pipes) throws Exception {
        usedPipeNames.add("Substring regexes");
        String[] substrings = { "cortic", "cerebel", "thalamic", "nuclei",
                "nucleus" };

        for (String substring : substrings) {
            pipes.add(new RegexMatches(substring + "Regex", Pattern.compile(
                    ".*" + substring + ".*", Pattern.CASE_INSENSITIVE)));
        }
    }

    public static void addSpineRegexPipes(List<String> usedPipeNames,
            List<Pipe> pipes) throws Exception {
        usedPipeNames.add("SpineRegex");
        // T1-T12
        // L1-L5
        // S1-S5
        // C1-C8
        // number of tokens depends on tokenizer
        // test at http://www.fileformat.info/tool/regex.htm
        pipes.add(new LongRegexMatches("SpinalParts", Pattern
                .compile("([LS][1-5])|T((1[0-2]?)|[2-9])|(C[1-8])"), 1, 2));

    }

    public static void addSmallLexicons(List<String> usedPipeNames,
            List<Pipe> pipes, boolean ignoreCase) throws FileNotFoundException {
        usedPipeNames.add("SmallLex");
        pipes.add(new LexiconMembership("chudlerListWord", new File(
                LEXICON_HOME + "chudler.txt"), ignoreCase));
        pipes.add(new LexiconMembership("directionWord", new File(LEXICON_HOME
                + "directions.txt"), ignoreCase));
        pipes.add(new LexiconMembership("extendedDirectionWord", new File(
                LEXICON_HOME + "extendedDirections.txt"), ignoreCase));
        pipes.add(new LexiconMembership("stopWord", new File(LEXICON_HOME
                + "stop.txt"), ignoreCase));
    }

    public static void addAreaLexicons(List<String> usedPipeNames,
            List<Pipe> pipes, boolean ignoreCase) throws FileNotFoundException {
        usedPipeNames.add("Areawords");
        pipes.add(new LexiconMembership("areawords", new File(LEXICON_HOME
                + "areawords.txt"), ignoreCase));
    }

    public static void addHandMadeRegexPipes(List<String> usedPipeNames,
            List<Pipe> pipes) throws Exception {
        usedPipeNames.add("Handmade regexes");
        pipes.add(new LongRegexMatches("of_The", Pattern.compile("of the"), 2,
                2));
        pipes.add(new LongRegexMatches("part_Of", Pattern.compile("part of"),
                2, 2));
        pipes.add(new LongRegexMatches("neuronEnd", Pattern
                .compile("(.* neurons)"), 2, 3));
        pipes.add(new LongRegexMatches("nucleiEnd", Pattern
                .compile("(.* nuclei)"), 2, 3));
        pipes.add(new LongRegexMatches("nucleusEnd", Pattern
                .compile("(.* nucleus)"), 2, 5));
        pipes.add(new LongRegexMatches("fieldEnd", Pattern
                .compile("(.* field)"), 2, 4));
        pipes.add(new LongRegexMatches("cortexEnd", Pattern
                .compile("(.* cortex)"), 2, 3));
        pipes.add(new LongRegexMatches("areaEnd", Pattern.compile("(.* area)"),
                2, 4));
        pipes.add(new LongRegexMatches("territoryEnd", Pattern
                .compile("(.* territory)|(.* territories)"), 2, 4));
    }

    public static void addLengthPipes(List<String> usedPipeNames,
            List<Pipe> pipes) throws Exception {
        usedPipeNames.add("Length");
        // length feature - binary bins
        pipes.add(new LengthBins("Length", new int[] { 1, 2, 3, 5, 8, 11, 14,
                18, 22 }));

        // from some calcs the average brain token is 6.92 while the outside is
        // 4.64 (~3.55 stdev)
        pipes.add(new LengthBins("LengthThreshold", new int[] { 6 }));
    }

    public static void addMalletNEPipes(List<String> usedPipeNames,
            List<Pipe> pipes) throws Exception {
        usedPipeNames.add("Mallet NE");
        // random pipes from general NER
        pipes.addAll(new NEPipes().pipes());
    }
}
